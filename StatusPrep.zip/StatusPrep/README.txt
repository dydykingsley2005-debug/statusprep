STATUS PREP - first version

1. Install Android Studio (free): developer.android.com/studio
2. Unzip this folder. In Android Studio: File > Open > select the StatusPrep folder.
3. Wait for "Gradle sync" to finish (needs internet, a few minutes).
4. Plug in your phone (Developer options + USB debugging on) and press the green Run button.
   To get an installable file: Build > Build APK(s).
5. In the app: Pick photo or video > choose clip length > Prepare > Share (opens WhatsApp > My status).
