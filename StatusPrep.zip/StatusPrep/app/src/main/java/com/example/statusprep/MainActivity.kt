package com.example.statusprep

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.*
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.min

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }
}

// Target: stay safely under WhatsApp's ~16 MB Status limit
private const val TARGET_BYTES = 14L * 1024 * 1024
private const val AUDIO_BITRATE = 128_000
private const val MAX_VIDEO_BITRATE = 5_000_000

@Composable
fun Screen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var clipSeconds by remember { mutableStateOf(30) }
    var status by remember { mutableStateOf("Pick a photo or video to start.") }
    var isPhoto by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var clips by remember { mutableStateOf<List<File>>(emptyList()) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            videoUri = uri
            clips = emptyList()
            isPhoto = ctx.contentResolver.getType(uri)?.startsWith("image") == true
            status = if (isPhoto) "Photo selected. Tap Prepare."
                     else "Video selected. Choose clip length, then tap Prepare."
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Status Prep", style = MaterialTheme.typography.headlineMedium)
        Text(status)

        Button(
            onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
            },
            enabled = !busy
        ) { Text("Pick photo or video") }

        if (!isPhoto) {
            Text("Clip length (long videos get split; Whole = no split)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 60, 90, 0).forEach { s ->
                    FilterChip(
                        selected = clipSeconds == s,
                        onClick = { if (!busy) clipSeconds = s },
                        label = { Text(if (s == 0) "Whole" else "${s}s") }
                    )
                }
            }
        }

        Button(
            onClick = {
                val uri = videoUri ?: return@Button
                busy = true
                clips = emptyList()
                scope.launch {
                    try {
                        val result = if (isPhoto) preparePhoto(ctx, uri) else prepare(ctx, uri, clipSeconds) { status = it }
                        clips = result
                        status = "Done. Tap Share, then choose My status in WhatsApp."
                    } catch (e: Exception) {
                        status = "Failed: ${e.message}"
                    } finally {
                        busy = false
                    }
                }
            },
            enabled = videoUri != null && !busy
        ) { Text(if (busy) "Working..." else "Prepare") }

        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())

        clips.forEachIndexed { i, f ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(14.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text((if (f.extension == "jpg") "Photo" else "Clip ${i + 1}") + "  (${"%.1f".format(f.length() / 1048576.0)} MB)")
                    Button(onClick = { shareToWhatsApp(ctx, f) }) { Text("Share") }
                }
            }
        }
    }
}

private fun shareToWhatsApp(ctx: Context, file: File) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
    val base = Intent(Intent.ACTION_SEND).apply {
        type = if (file.extension == "jpg") "image/jpeg" else "video/mp4"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    // Try WhatsApp first, then WhatsApp Business
    for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
        try {
            ctx.startActivity(Intent(base).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (_: Exception) { }
    }
    Toast.makeText(ctx, "WhatsApp not found", Toast.LENGTH_LONG).show()
}

private suspend fun prepare(
    ctx: Context,
    uri: Uri,
    clipSeconds: Int,
    onStatus: (String) -> Unit
): List<File> {
    val info = withContext(Dispatchers.IO) { readInfo(ctx, uri) }
    val dir = File(ctx.cacheDir, "clips").apply { mkdirs(); listFiles()?.forEach { it.delete() } }

    val clipMs = if (clipSeconds == 0) info.durationMs.coerceAtLeast(1000L) else clipSeconds * 1000L
    val count = ((info.durationMs + clipMs - 1) / clipMs).toInt().coerceAtLeast(1)
    val out = mutableListOf<File>()

    // Scale so the shorter side is at most 720 px (never upscale)
    val shortSide = min(info.width, info.height)
    val scale = min(1f, 720f / shortSide)
    val targetH = (info.height * scale).toInt().let { it - it % 2 }

    for (i in 0 until count) {
        val start = i * clipMs
        val end = min(info.durationMs, start + clipMs)
        val lenSec = ((end - start) / 1000.0).coerceAtLeast(1.0)
        val bitrate = ((TARGET_BYTES * 8 / lenSec) - AUDIO_BITRATE)
            .toInt().coerceIn(500_000, MAX_VIDEO_BITRATE)

        onStatus("Compressing clip ${i + 1} of $count...")
        val f = File(dir, "status_${i + 1}.mp4")
        transcode(ctx, uri, start, end, targetH, bitrate, f)
        out += f
    }
    return out
}

private data class Info(val width: Int, val height: Int, val durationMs: Long)

private fun readInfo(ctx: Context, uri: Uri): Info {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(ctx, uri)
        var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
        var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
        if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong()
        return Info(w, h, d)
    } finally {
        r.release()
    }
}

private suspend fun transcode(
    ctx: Context,
    uri: Uri,
    startMs: Long,
    endMs: Long,
    targetHeight: Int,
    bitrate: Int,
    out: File
) = withContext(Dispatchers.Main) {
    suspendCancellableCoroutine<Unit> { cont ->
        val item = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            ).build()

        val effects = Effects(
            emptyList(),
            listOf<Effect>(Presentation.createForHeight(targetHeight))
        )
        val edited = EditedMediaItem.Builder(item).setEffects(effects).build()

        val encoder = DefaultEncoderFactory.Builder(ctx)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(bitrate).build()
            ).build()

        val transformer = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoder)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    if (cont.isActive) cont.resume(Unit)
                }
                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    if (cont.isActive) cont.resumeWithException(exportException)
                }
            }).build()

        if (out.exists()) out.delete()
        transformer.start(edited, out.absolutePath)
        cont.invokeOnCancellation { transformer.cancel() }
    }
}


// Photos: resize so the long side is 1600 px (what WhatsApp targets anyway),
// save as high-quality JPEG so WhatsApp has little left to damage.
private suspend fun preparePhoto(ctx: Context, uri: Uri): List<File> = withContext(Dispatchers.IO) {
    val dir = File(ctx.cacheDir, "clips").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
    val source = ImageDecoder.createSource(ctx.contentResolver, uri)
    val bmp: Bitmap = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val w = info.size.width
        val h = info.size.height
        val longSide = maxOf(w, h)
        if (longSide > 1600) {
            val k = 1600f / longSide
            decoder.setTargetSize((w * k).toInt(), (h * k).toInt())
        }
    }
    val out = File(dir, "status_photo.jpg")
    FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    listOf(out)
}
